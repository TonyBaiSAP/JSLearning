## 网站性能优化项目

# Web optimization
>Reduce network request
>Use inline mode define css in html style
>Use async mode request external javascript resouce
>limit image size, if your image size too large, it will increase network request cost
>In your JS file, do not change html tag style, consider about define in CSS, otherwise, don't change style in loop
>As possible as define random resouce in your current screen. 
>Consider about use define box mode in your CSS to annimate resource.