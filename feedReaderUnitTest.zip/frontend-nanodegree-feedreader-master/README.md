# Jasmine reference
>https://jasmine.github.io/api/edge/matchers.html
>We can find the matchers

# How to write unit test
>1. Define expectation
>2. If the expectation is false, we need consider about use dummy test data, and the the test data should be deleted.